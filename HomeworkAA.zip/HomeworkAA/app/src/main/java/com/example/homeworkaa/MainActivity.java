package com.example.homeworkaa;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etJavaMarks, etDBMSMarks, etPythonMarks;
    private Spinner spinnerCourse;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etJavaMarks = findViewById(R.id.etJavaMarks);
        etDBMSMarks = findViewById(R.id.etDBMSMarks);
        etPythonMarks = findViewById(R.id.etPythonMarks);
        spinnerCourse = findViewById(R.id.spinnerCourse);
        Button btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.courses, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourse.setAdapter(adapter);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculatePercentage();
            }
        });
    }

    private void calculatePercentage() {
        // Get user input
        String name = etName.getText().toString();
        String course = spinnerCourse.getSelectedItem().toString();
        double javaMarks = Double.parseDouble(etJavaMarks.getText().toString());
        double dbmsMarks = Double.parseDouble(etDBMSMarks.getText().toString());
        double pythonMarks = Double.parseDouble(etPythonMarks.getText().toString());

        // Calculate percentage (assuming equal weight for all subjects)
        double totalMarks = javaMarks + dbmsMarks + pythonMarks;
        double percentage = (totalMarks / 300) * 100;

        // Display the result
        String resultMessage = "Name: " + name + "\nCourse: " + course + "\nPercentage: " + percentage + "%";
        tvResult.setText(resultMessage);
    }
}
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.os.Bundle;
//
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//}